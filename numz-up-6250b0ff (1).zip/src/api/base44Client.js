import { createClient } from '@base44/sdk';
// import { getAccessToken } from '@base44/sdk/utils/auth-utils';

// Create a client with authentication required
export const base44 = createClient({
  appId: "6853fa0aa44753b66250b0ff", 
  requiresAuth: true // Ensure authentication is required for all operations
});
