import { base44 } from './base44Client';


export const GameSession = base44.entities.GameSession;



// auth sdk:
export const User = base44.auth;