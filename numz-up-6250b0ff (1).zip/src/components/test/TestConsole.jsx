import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Code, 
  AlertTriangle, 
  Plus, 
  Minus, 
  Lightbulb, 
  RotateCcw, 
  Lock, 
  Unlock, 
  ShieldOff,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

const PASSKEY = '7wxao77jgbc';
const MAX_ATTEMPTS = 3;

export default function TestConsole({
  enabledDigits,
  onDigitToggle,
  hintsAvailable,
  onHintsChange,
  rowsAdded,
  onRowsAddedChange
}) {
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [showPasskeyInput, setShowPasskeyInput] = useState(false);
  const [passkeyInput, setPasskeyInput] = useState('');
  const [attempts, setAttempts] = useState(0);
  const [isLocked, setIsLocked] = useState(false);
  const [showPasskeyError, setShowPasskeyError] = useState(false);

  const handlePasskeySubmit = (e) => {
    e.preventDefault();
    if (isLocked) return;

    if (passkeyInput === PASSKEY) {
      setIsUnlocked(true);
      setIsExpanded(true);
      setShowPasskeyInput(false);
      setPasskeyInput('');
      setShowPasskeyError(false);
    } else {
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);
      setShowPasskeyError(true);
      setPasskeyInput('');
      if (newAttempts >= MAX_ATTEMPTS) {
        setIsLocked(true);
        setShowPasskeyInput(false);
      }
      setTimeout(() => setShowPasskeyError(false), 3000);
    }
  };
  
  const handleToggleVisibility = () => {
    if (isLocked) return;
    if (isUnlocked) {
      setIsExpanded(prev => !prev);
    } else {
      setShowPasskeyInput(prev => !prev);
    }
  };

  const allDisabled = enabledDigits.length === 0;
  const maxRowsAdded = 5;

  return (
    <div className="bg-slate-800 border-b border-slate-700 text-white p-4">
      <div className="max-w-4xl mx-auto">
        <div 
          className="flex items-center justify-between cursor-pointer"
          onClick={handleToggleVisibility}
        >
          <div className="flex items-center gap-3">
            <Code className="w-5 h-5 text-emerald-400" />
            <h3 className="font-semibold">Developer Console</h3>
          </div>
          <div className="flex items-center gap-3">
            {isUnlocked ? (
              <Badge variant="outline" className="bg-green-500/10 text-green-400 border-green-500/20">
                <Unlock className="w-3 h-3 mr-1" />
                Unlocked
              </Badge>
            ) : isLocked ? (
              <Badge variant="destructive">
                <ShieldOff className="w-3 h-3 mr-1" />
                Locked
              </Badge>
            ) : (
              <Badge variant="secondary">
                <Lock className="w-3 h-3 mr-1" />
                Locked
              </Badge>
            )}
            {isUnlocked && (
              isExpanded 
                ? <ChevronUp className="w-5 h-5 text-slate-400" />
                : <ChevronDown className="w-5 h-5 text-slate-400" />
            )}
          </div>
        </div>

        <AnimatePresence>
          {showPasskeyInput && !isUnlocked && !isLocked && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-4 overflow-hidden"
            >
              <form onSubmit={handlePasskeySubmit} className="space-y-3 bg-slate-900/50 p-4 rounded-lg">
                <Input
                  type="password"
                  value={passkeyInput}
                  onChange={(e) => setPasskeyInput(e.target.value)}
                  placeholder="Enter passkey to unlock controls..."
                  className="bg-slate-700 border-slate-600 text-white placeholder-slate-400"
                  autoFocus
                />
                <div className="flex items-center justify-between">
                  <Button type="submit" size="sm" className="bg-emerald-600 hover:bg-emerald-700 text-white">
                    Unlock
                  </Button>
                  <span className="text-xs text-slate-400">
                    Attempts: {attempts}/{MAX_ATTEMPTS}
                  </span>
                </div>
                {showPasskeyError && (
                  <motion.p 
                    initial={{ opacity: 0}}
                    animate={{ opacity: 1}}
                    className="text-red-400 text-xs flex items-center gap-2 pt-2">
                    <AlertTriangle className="w-4 h-4" />
                    Incorrect passkey. {MAX_ATTEMPTS - attempts} remaining.
                  </motion.p>
                )}
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {isUnlocked && isExpanded && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-4 pt-4 border-t border-slate-700/50 overflow-hidden"
            >
              <div className="space-y-4">
                {/* ROW 1 */}
                <div className="space-y-2">
                   <label className="text-sm text-slate-300 block">Available Digits</label>
                    <div className="flex flex-wrap gap-2">
                      {[1,2,3,4,5,6,7,8,9].map(digit => (
                        <Button key={digit} variant={enabledDigits.includes(digit) ? "default" : "outline"} size="sm" onClick={() => onDigitToggle(digit)} className={`w-9 h-9 p-0 text-xs ${enabledDigits.includes(digit) ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-slate-700 hover:bg-slate-600'}`}>
                          {digit}
                        </Button>
                      ))}
                    </div>
                   {allDisabled && <div className="flex items-center gap-2 p-2 bg-red-500/10 border border-red-500/20 rounded-md text-xs"><AlertTriangle className="w-4 h-4 text-red-400" /><span className="text-red-300">At least one digit must be enabled.</span></div>}
                </div>
                
                {/* ROW 2 */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm text-slate-300 block">Hints</label>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="icon" onClick={() => onHintsChange(Math.max(0, hintsAvailable - 1))} className="w-8 h-8 p-0 bg-slate-700 hover:bg-slate-600 shrink-0"><Minus className="w-4 h-4" /></Button>
                      <div className="flex items-center justify-center gap-2 flex-grow h-8 px-2 bg-amber-500/10 border border-amber-500/20 rounded-md"><Lightbulb className="w-4 h-4 text-amber-400" /><span className="text-amber-300 font-mono text-center">{hintsAvailable}</span></div>
                      <Button variant="outline" size="icon" onClick={() => onHintsChange(hintsAvailable + 1)} className="w-8 h-8 p-0 bg-slate-700 hover:bg-slate-600 shrink-0"><Plus className="w-4 h-4" /></Button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm text-slate-300 block">Added Rows</label>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="icon" onClick={() => onRowsAddedChange(Math.max(0, rowsAdded - 1))} className="w-8 h-8 p-0 bg-slate-700 hover:bg-slate-600 shrink-0"><Minus className="w-4 h-4" /></Button>
                      <div className="flex items-center justify-center gap-2 flex-grow h-8 px-2 bg-blue-500/10 border border-blue-500/20 rounded-md"><RotateCcw className="w-4 h-4 text-blue-400" /><span className="text-blue-300 font-mono text-center">{rowsAdded}/{maxRowsAdded}</span></div>
                      <Button variant="outline" size="icon" onClick={() => onRowsAddedChange(Math.min(maxRowsAdded, rowsAdded + 1))} className="w-8 h-8 p-0 bg-slate-700 hover:bg-slate-600 shrink-0"><Plus className="w-4 h-4" /></Button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}