
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Lightbulb,
  RotateCcw,
  Plus,
  Zap,
  Trophy,
  AlertCircle,
  RefreshCw
} from 'lucide-react';

import GameCell from './GameCell';
import MatchLine from './MatchLine';
import GameOverModal from './GameOverModal';

const DIFFICULTY_CONFIG = {
  easy: { rows: 9, cols: 9, hintInterval: 5 },
  medium: { rows: 11, cols: 9, hintInterval: 9 },
  hard: { rows: 13, cols: 9, hintInterval: 15 }
};

export default function GameBoard({
  difficulty = 'easy',
  onGameComplete,
  onScoreUpdate,
  enabledDigits = [1,2,3,4,5,6,7,8,9],
  testMode = false,
  testHints = 1,
  testRowsAdded = 0,
  onTestHintsChange,
  onTestRowsAddedChange
}) {
  const config = DIFFICULTY_CONFIG[difficulty];
  const cellIdCounter = useRef(0);
  const [board, setBoard] = useState([]);
  const [selectedCells, setSelectedCells] = useState([]);
  const [matchHistory, setMatchHistory] = useState([]);
  const [matchesCount, setMatchesCount] = useState(0);
  const [hintsAvailable, setHintsAvailable] = useState(testMode ? testHints : 1);
  const [rowsAdded, setRowsAdded] = useState(testMode ? testRowsAdded : 0);
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [gameWon, setGameWon] = useState(false);
  const [showHint, setShowHint] = useState(null);
  const [pendingClears, setPendingClears] = useState(new Set());

  // Use refs to hold the latest test prop values without making them dependencies of resetGame
  const testHintsRef = useRef(testHints);
  testHintsRef.current = testHints;
  const testRowsAddedRef = useRef(testRowsAdded);
  testRowsAddedRef.current = testRowsAdded;

  // Sync test mode values with game state when they change
  useEffect(() => {
    if (testMode) {
      setHintsAvailable(testHints);
    }
  }, [testMode, testHints]);

  useEffect(() => {
    if (testMode) {
      setRowsAdded(testRowsAdded);
    }
  }, [testMode, testRowsAdded]);

  const generateBoard = useCallback(() => {
    cellIdCounter.current = 0;
    const availableDigits = enabledDigits.filter(d => d >= 1 && d <= 9);
    if (availableDigits.length === 0) return [];

    const newBoard = [];
    for (let i = 0; i < config.rows; i++) {
      const row = [];
      for (let j = 0; j < config.cols; j++) {
        const randomDigit = availableDigits[Math.floor(Math.random() * availableDigits.length)];
        row.push({
          value: randomDigit,
          cleared: false,
          id: cellIdCounter.current++,
          row: i,
          col: j,
          glowAnimation: null
        });
      }
      newBoard.push(row);
    }
    return newBoard;
  }, [config.rows, config.cols, enabledDigits]);

  const resetGame = useCallback(() => {
    const newBoard = generateBoard();
    setBoard(newBoard);
    setSelectedCells([]);
    setMatchHistory([]);
    setMatchesCount(0);
    setHintsAvailable(testMode ? testHintsRef.current : 1);
    setRowsAdded(testMode ? testRowsAddedRef.current : 0);
    setScore(0);
    setGameOver(false);
    setGameWon(false);
    setPendingClears(new Set());
  }, [generateBoard, testMode]);

  // This effect will now run ONLY when difficulty or enabledDigits change,
  // triggering a board reset as intended.
  useEffect(() => {
    resetGame();
  }, [resetGame]);

  const canMatch = useCallback((cell1, cell2, currentBoard, pendingClearsSet) => {
    const { row: r1, col: c1 } = cell1;
    const { row: r2, col: c2 } = cell2;

    const cell1Key = `${r1}-${c1}`;
    const cell2Key = `${r2}-${c2}`;

    if (currentBoard[r1][c1].cleared || currentBoard[r2][c2].cleared ||
        pendingClearsSet.has(cell1Key) || pendingClearsSet.has(cell2Key)) {
      return false;
    }

    const val1 = currentBoard[r1][c1].value;
    const val2 = currentBoard[r2][c2].value;

    const isValidMatch = val1 === val2 || val1 + val2 === 10;
    if (!isValidMatch) return false;

    // Check if both cells are the only non-cleared cells in their respective rows
    const row1ActiveCells = currentBoard[r1].filter(cell => {
      const cellKey = `${cell.row}-${cell.col}`;
      return !cell.cleared && !pendingClearsSet.has(cellKey);
    });
    const row2ActiveCells = currentBoard[r2].filter(cell => {
      const cellKey = `${cell.row}-${cell.col}`;
      return !cell.cleared && !pendingClearsSet.has(cellKey);
    });

    // Special case: if both cells are the only active cells in their rows, they can match
    if (row1ActiveCells.length === 1 && row2ActiveCells[0] && 
        row1ActiveCells[0].id === cell1.id && row2ActiveCells.length === 1 && 
        row2ActiveCells[0].id === cell2.id) {
      return true;
    }

    const sameRow = r1 === r2;
    const sameCol = c1 === c2;
    const sameDiag = Math.abs(r1 - r2) === Math.abs(c1 - c2);

    if (!sameRow && !sameCol && !sameDiag) return false;

    const stepR = r1 === r2 ? 0 : (r2 - r1) / Math.abs(r2 - r1);
    const stepC = c1 === c2 ? 0 : (c2 - c1) / Math.abs(c2 - c1);

    let currentR = r1 + stepR;
    let currentC = c1 + stepC;

    while (currentR !== r2 || currentC !== c2) {
      const cellKey = `${currentR}-${currentC}`;
      if (currentBoard[currentR][currentC] &&
          !currentBoard[currentR][currentC].cleared &&
          !pendingClearsSet.has(cellKey)) {
        return false;
      }
      currentR += stepR;
      currentC += stepC;
    }

    return true;
  }, []);

  const calculateMatchScore = useCallback((cell1, cell2) => {
    const baseScore = 2; // Base score for every match
    const { row: r1, col: c1 } = cell1;
    const { row: r2, col: c2 } = cell2;

    // Check if it's the special case where both cells are the only active cells in their rows
    const row1ActiveCells = board[r1].filter(cell => {
      const cellKey = `${cell.row}-${cell.col}`;
      return !cell.cleared && !pendingClears.has(cellKey) && cell.id !== cell1.id && cell.id !== cell2.id;
    });
    const row2ActiveCells = board[r2].filter(cell => {
      const cellKey = `${cell.row}-${cell.col}`;
      return !cell.cleared && !pendingClears.has(cellKey) && cell.id !== cell1.id && cell.id !== cell2.id;
    });

    const isSpecialMatch = (row1ActiveCells.length === 0 && row2ActiveCells.length === 0 && 
                            r1 !== r2);

    if (isSpecialMatch) {
      // For special matches (single cells in different rows), just return base score
      return baseScore;
    }

    const sameRow = r1 === r2;
    const sameCol = c1 === c2;
    const sameDiag = Math.abs(r1 - r2) === Math.abs(c1 - c2);

    let bonusScore = 0;

    if (sameRow) {
      // Same row: bonus = number of columns between the matched digits
      const colDiff = Math.abs(c1 - c2);
      bonusScore = Math.max(0, colDiff - 1); // Subtract 1 to exclude the matched tiles themselves
    } else if (sameCol) {
      // Same column: bonus = number of rows between the matched digits
      const rowDiff = Math.abs(r1 - r2);
      bonusScore = Math.max(0, rowDiff - 1); // Subtract 1 to exclude the matched tiles themselves
    } else if (sameDiag) {
      // Diagonal: bonus = number of diagonal steps between the matched digits
      const diagDiff = Math.abs(r1 - r2); // Same as Math.abs(c1 - c2) for diagonal
      bonusScore = Math.max(0, diagDiff - 1); // Subtract 1 to exclude the matched tiles themselves
    }

    return baseScore + bonusScore;
  }, [board, pendingClears]);

  const makeMatch = useCallback((cell1, cell2) => {
    const cell1Id = cell1.id;
    const cell2Id = cell2.id;
    const cell1Key = `${cell1.row}-${cell1.col}`;
    const cell2Key = `${cell2.row}-${cell2.col}`;

    // Calculate score for this match immediately using current board state
    const matchScore = calculateMatchScore(cell1, cell2);

    // Update score and match count immediately
    const newMatchCount = matchesCount + 1;
    const newScore = score + matchScore;

    setMatchesCount(newMatchCount);
    setScore(newScore);
    onScoreUpdate?.(newScore);

    // Check for hint earning immediately
    if (newMatchCount % config.hintInterval === 0) {
      const newHints = hintsAvailable + 1;
      setHintsAvailable(newHints);
      if (testMode && onTestHintsChange) {
        onTestHintsChange(newHints);
      }
    }

    setMatchHistory(prev => [...prev, { board, score, matchesCount, hintsAvailable, pendingClears }]);
    setPendingClears(prev => new Set([...prev, cell1Key, cell2Key]));

    setBoard(prevBoard => {
      let newBoard = prevBoard.map(row => row.map(cell => ({ ...cell })));
      const path = [];
      const { row: r1, col: c1 } = cell1;
      const { row: r2, col: c2 } = cell2;

      // Determine if it's the special case match (isolated cells in different rows)
      const row1ActiveCells = newBoard[r1].filter(cell => !cell.cleared && !pendingClears.has(`${cell.row}-${cell.col}`));
      const row2ActiveCells = newBoard[r2].filter(cell => !cell.cleared && !pendingClears.has(`${cell.row}-${cell.col}`));
      const isSpecialMatch = (row1ActiveCells.length === 1 && row2ActiveCells.length === 1 &&
                              row1ActiveCells[0].id === cell1.id && row2ActiveCells[0].id === cell2.id);

      if (!isSpecialMatch) { // Only animate path if it's a regular line-of-sight match
        const stepR = r1 === r2 ? 0 : (r2 - r1) / Math.abs(r2 - r1);
        const stepC = c1 === c2 ? 0 : (c2 - c1) / Math.abs(c2 - c1);

        let currentR = r1;
        let currentC = c1;

        while (true) {
          path.push({ row: currentR, col: currentC });
          if (currentR === r2 && currentC === c2) break;
          currentR += stepR;
          currentC += stepC;
        }
      } else {
        // For special matches, just highlight the two cells
        path.push({ row: r1, col: c1 });
        path.push({ row: r2, col: c2 });
      }

      const animationDelayFactor = 0.04;
      path.forEach(({ row, col }, index) => {
        if (newBoard[row] && newBoard[row][col]) {
          newBoard[row][col].glowAnimation = { delay: index * animationDelayFactor };
        }
      });
      return newBoard;
    });

    setTimeout(() => {
      setBoard(prevBoard => {
        let boardAfterGlow = prevBoard.map(row => row.map(cell => ({ ...cell, glowAnimation: null })));

        let nextBoard = boardAfterGlow.map(row => row.map(cell => {
          if (cell.id === cell1Id || cell.id === cell2Id) {
            return { ...cell, cleared: true };
          }
          return cell;
        }));

        const completedRows = [];
        nextBoard.forEach((row, index) => {
          if (row.every(c => c.cleared)) {
            completedRows.push(index);
          }
        });

        if (completedRows.length > 0) {
          nextBoard = nextBoard.filter((_, index) => !completedRows.includes(index))
            .map((row, newRowIndex) => row.map(cell => ({ ...cell, row: newRowIndex })));
        }

        return nextBoard;
      });

      setPendingClears(prev => {
        const newSet = new Set(prev);
        newSet.delete(cell1Key);
        newSet.delete(cell2Key);
        return newSet;
      });
    }, 800);
  }, [score, matchesCount, hintsAvailable, config.hintInterval, onScoreUpdate, board, pendingClears, testMode, onTestHintsChange, calculateMatchScore]);

  const handleCellClick = useCallback((row, col) => {
    const clickedCell = board[row]?.[col];
    if (!clickedCell) return;

    const cellKey = `${clickedCell.row}-${clickedCell.col}`;
    if (clickedCell.cleared || pendingClears.has(cellKey)) {
        return;
    }

    setSelectedCells(prev => {
        if (prev.length === 0) {
            return [clickedCell];
        } else if (prev.length === 1) {
            const firstCell = prev[0];
            if (firstCell.id === clickedCell.id) {
                return [];
            }
            if (canMatch(firstCell, clickedCell, board, pendingClears)) {
                makeMatch(firstCell, clickedCell);
                return [];
            } else {
                return [clickedCell];
            }
        }
        return prev;
    });
  }, [board, canMatch, makeMatch, pendingClears]);

  const findValidMatch = useCallback(() => {
    for (let r1 = 0; r1 < board.length; r1++) {
      for (let c1 = 0; c1 < board[r1].length; c1++) {
        const cell1 = board[r1][c1];
        const cell1Key = `${r1}-${c1}`;
        if (cell1.cleared || pendingClears.has(cell1Key)) continue;

        for (let r2 = 0; r2 < board.length; r2++) {
          for (let c2 = 0; c2 < board[r2].length; c2++) {
            const cell2 = board[r2][c2];
            if (cell1.id === cell2.id) continue;
            const cell2Key = `${r2}-${c2}`;
            if (cell2.cleared || pendingClears.has(cell2Key)) continue;

            if (canMatch(cell1, cell2, board, pendingClears)) {
              return { from: cell1, to: cell2 };
            }
          }
        }
      }
    }
    return null;
  }, [board, canMatch, pendingClears]);

  const useHint = useCallback(() => {
    if (hintsAvailable <= 0) return;

    const validMatch = findValidMatch();
    if (validMatch) {
      const newHints = hintsAvailable - 1;
      setHintsAvailable(newHints);
      if (testMode && onTestHintsChange) {
        onTestHintsChange(newHints);
      }
      setShowHint(validMatch);
      setTimeout(() => setShowHint(null), 1000);
    }
  }, [hintsAvailable, findValidMatch, testMode, onTestHintsChange]);

  const undoLastMatch = useCallback(() => {
    if (matchHistory.length === 0) return;

    const lastState = matchHistory[matchHistory.length - 1];

    setBoard(lastState.board);
    setScore(lastState.score);
    setMatchesCount(lastState.matchesCount);
    setHintsAvailable(lastState.hintsAvailable);
    setPendingClears(lastState.pendingClears);
    setSelectedCells([]);

    setMatchHistory(prev => prev.slice(0, -1));
  }, [matchHistory]);

  const addRows = useCallback(() => {
    if (rowsAdded >= 5) return;

    const newRows = [];
    // Calculate the actual current last row index from the current board state
    const currentMaxRowIndex = board.reduce((maxIdx, row) =>
      Math.max(maxIdx, ...row.map(cell => cell.row)), -1);

    for (let i = 0; i < 2; i++) {
      const row = [];
      const newRowIdx = currentMaxRowIndex + 1 + i; // Correctly calculate new row index based on current max
      for (let j = 0; j < config.cols; j++) {
        const availableDigits = enabledDigits.filter(d => d >= 1 && d <= 9);
        const randomDigit = availableDigits.length > 0
          ? availableDigits[Math.floor(Math.random() * availableDigits.length)]
          : 1;
        row.push({
          value: randomDigit,
          cleared: false,
          id: cellIdCounter.current++,
          row: newRowIdx, // Assign new row index
          col: j,
          glowAnimation: null
        });
      }
      newRows.push(row);
    }

    setBoard(prev => [...prev, ...newRows]);
    const newRowsAdded = rowsAdded + 1;
    setRowsAdded(newRowsAdded);
    if (testMode && onTestRowsAddedChange) {
      onTestRowsAddedChange(newRowsAdded);
    }
  }, [rowsAdded, config.cols, enabledDigits, board, testMode, onTestRowsAddedChange]);

  useEffect(() => {
    if (board.length > 0 && board.every(row => row.every(cell => cell.cleared))) {
      setGameWon(true);
      setGameOver(true);
      onGameComplete?.(true, score);
      return;
    }
    if (board.length === 0 && matchesCount > 0) {
      setGameWon(true);
      setGameOver(true);
      onGameComplete?.(true, score);
      return;
    }
    if (board.length === 0) return;

    const hasActiveCells = board.some(row => row.some(cell => !cell.cleared)) || pendingClears.size > 0;
    const hasValidMoves = findValidMatch() !== null;

    if (!hasActiveCells && pendingClears.size === 0) {
      setGameWon(true);
      setGameOver(true);
      onGameComplete?.(true, score);
    } else if (!hasValidMoves && rowsAdded >= 5 && pendingClears.size === 0) {
      setGameOver(true);
      onGameComplete?.(false, score);
    }
  }, [board, findValidMatch, rowsAdded, score, onGameComplete, matchesCount, pendingClears]);

  const shouldPulseAddRows = useCallback(() => {
    const hasActiveCells = board.some(row => row.some(cell => !cell.cleared)) || pendingClears.size > 0;
    const hasValidMoves = findValidMatch() !== null;
    return hasActiveCells && !hasValidMoves && rowsAdded < 5;
  }, [board, pendingClears, findValidMatch, rowsAdded]);

  return (
    <div className="flex flex-col h-full bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Game Stats */}
      <div className="flex justify-between items-center p-4 bg-white/80 backdrop-blur-sm border-b border-slate-200">
        <div className="flex items-center gap-4">
          <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200">
            <Trophy className="w-3 h-3 mr-1" />
            {score}
          </Badge>
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Matches: {matchesCount}
          </Badge>
        </div>
        <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200 capitalize">
          {difficulty}
        </Badge>
      </div>

      {/* Game Controls */}
      <div className="flex justify-center items-center gap-2 sm:gap-3 p-4 bg-white/60 backdrop-blur-sm flex-wrap">
        <Button
          variant="outline"
          size="sm"
          onClick={useHint}
          disabled={hintsAvailable <= 0 || !findValidMatch()}
          className="flex items-center gap-2 bg-amber-50 hover:bg-amber-100 text-amber-700 border-amber-200"
        >
          <Lightbulb className="w-4 h-4" />
          Hint ({hintsAvailable})
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={undoLastMatch}
          disabled={matchHistory.length === 0}
          className="flex items-center gap-2"
        >
          <RotateCcw className="w-4 h-4" />
          Undo
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={resetGame}
          className="flex items-center gap-2"
        >
          <RefreshCw className="w-4 h-4" />
          Restart
        </Button>
        <motion.div
          animate={shouldPulseAddRows() ? {
            scale: [1, 1.05, 1],
            boxShadow: [
              "0 0 0 0 rgba(59, 130, 246, 0)",
              "0 0 0 10px rgba(59, 130, 246, 0.3)",
              "0 0 0 0 rgba(59, 130, 246, 0)"
            ]
          } : {}}
          transition={{
            duration: 2,
            repeat: shouldPulseAddRows() ? Infinity : 0,
            ease: "easeInOut"
          }}
          className="rounded-md"
        >
          <Button
            variant="outline"
            size="sm"
            onClick={addRows}
            disabled={rowsAdded >= 5}
            className={`flex items-center gap-2 bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200 ${
              shouldPulseAddRows() ? 'ring-2 ring-blue-300 ring-opacity-50' : ''
            }`}
          >
            <Plus className="w-4 h-4" />
            Add Rows ({5 - rowsAdded})
          </Button>
        </motion.div>
      </div>

      {/* Game Board */}
      <div className="flex-1 flex items-center justify-center p-4 overflow-auto">
        <div className="relative">
          <motion.div
            layout
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="grid gap-1 sm:gap-2 p-1 sm:p-2 bg-white rounded-2xl shadow-xl border border-slate-200"
            style={{
              gridTemplateColumns: `repeat(${config.cols}, 1fr)`,
              maxWidth: '90vw',
              maxHeight: '85vh',
            }}
          >
            <AnimatePresence>
              {board.map((row, rowIndex) =>
                row.map((cell, colIndex) => {
                  const cellKey = `${cell.row}-${cell.col}`;
                  const isPending = pendingClears.has(cellKey);

                  return (
                    <GameCell
                      key={cell.id}
                      value={cell.value}
                      cleared={cell.cleared}
                      pending={isPending}
                      selected={selectedCells.some(s => s.id === cell.id)}
                      hinted={showHint && (showHint.from.id === cell.id || showHint.to.id === cell.id)}
                      glowAnimation={cell.glowAnimation}
                      onClick={() => handleCellClick(rowIndex, colIndex)}
                    />
                  );
                })
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </div>

      <GameOverModal
        isOpen={gameOver}
        won={gameWon}
        score={score}
        matches={matchesCount}
        difficulty={difficulty}
        onRestart={resetGame}
        onNewGame={() => window.location.reload()}
      />
    </div>
  );
}
