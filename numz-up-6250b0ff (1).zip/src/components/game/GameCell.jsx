import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export default function GameCell({ 
  value, 
  cleared, 
  pending,
  selected, 
  hinted, 
  glowAnimation,
  onClick 
}) {
  return (
    <motion.button
      onClick={onClick}
      disabled={cleared || pending}
      className={`
        relative aspect-square rounded-lg font-bold text-lg sm:text-xl md:text-2xl
        transition-all duration-200 border-2 shadow-sm
        flex items-center justify-center
        ${cleared 
          ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed' 
          : pending
            ? 'bg-slate-200 text-slate-500 border-slate-300 cursor-not-allowed opacity-75'
          : selected 
            ? 'bg-blue-500 text-white border-blue-600 shadow-lg transform scale-105' 
            : hinted
              ? 'bg-amber-100 text-amber-800 border-amber-300 shadow-md'
              : 'bg-white text-slate-800 border-slate-300 hover:bg-slate-50 hover:border-slate-400 active:transform active:scale-95'
        }
      `}
      layout
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      exit={{ scale: 0, opacity: 0 }}
      whileHover={!cleared && !pending ? { scale: 1.05 } : {}}
      whileTap={!cleared && !pending ? { scale: 0.95 } : {}}
      transition={{ type: "spring", stiffness: 300, damping: 25 }}
    >
      <AnimatePresence>
        {glowAnimation && (
          <motion.div
            className="absolute inset-0 bg-blue-400/50 backdrop-blur-sm rounded-lg border-2 border-blue-300/80 pointer-events-none"
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.5 }}
            transition={{ duration: 0.3, delay: glowAnimation.delay }}
          />
        )}
      </AnimatePresence>
      
      {!cleared && (
        <motion.span
          className="relative z-10"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.1 }}
        >
          {value}
        </motion.span>
      )}
      
      {hinted && (
        <motion.div
          className="absolute inset-0 bg-amber-300/60 rounded-lg pointer-events-none z-20"
          animate={{ 
            opacity: [0.3, 0.8, 0.3],
            scale: [1, 1.1, 1]
          }}
          transition={{ 
            duration: 0.5, 
            repeat: 1, // Will pulse twice (on-off-on-off)
            ease: "easeInOut"
          }}
        />
      )}
    </motion.button>
  );
}