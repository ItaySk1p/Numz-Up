import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { 
  Trophy, 
  RotateCcw, 
  Home, 
  Star,
  Target,
  Zap 
} from 'lucide-react';

export default function GameOverModal({ 
  isOpen, 
  won, 
  score, 
  matches, 
  difficulty, 
  onRestart, 
  onNewGame 
}) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            className="bg-white rounded-3xl p-8 max-w-sm w-full shadow-2xl border border-slate-200"
            initial={{ scale: 0.8, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.8, opacity: 0, y: 20 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
          >
            <div className="text-center space-y-6">
              {/* Icon */}
              <motion.div
                className={`w-20 h-20 rounded-full mx-auto flex items-center justify-center ${
                  won ? 'bg-emerald-100' : 'bg-amber-100'
                }`}
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ delay: 0.2, type: "spring", stiffness: 300 }}
              >
                {won ? (
                  <Trophy className="w-10 h-10 text-emerald-600" />
                ) : (
                  <Target className="w-10 h-10 text-amber-600" />
                )}
              </motion.div>

              {/* Title */}
              <div>
                <h2 className="text-2xl font-bold text-slate-900 mb-2">
                  {won ? 'Congratulations!' : 'Game Over'}
                </h2>
                <p className="text-slate-600">
                  {won 
                    ? 'You cleared the entire board!' 
                    : 'No more moves available'}
                </p>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 py-4">
                <div className="text-center">
                  <div className={`w-12 h-12 rounded-xl mx-auto mb-2 flex items-center justify-center ${
                    won ? 'bg-emerald-50' : 'bg-slate-50'
                  }`}>
                    <Star className={`w-6 h-6 ${won ? 'text-emerald-600' : 'text-slate-400'}`} />
                  </div>
                  <div className="text-lg font-bold text-slate-900">{score}</div>
                  <div className="text-xs text-slate-500">Score</div>
                </div>
                
                <div className="text-center">
                  <div className={`w-12 h-12 rounded-xl mx-auto mb-2 flex items-center justify-center ${
                    won ? 'bg-blue-50' : 'bg-slate-50'
                  }`}>
                    <Zap className={`w-6 h-6 ${won ? 'text-blue-600' : 'text-slate-400'}`} />
                  </div>
                  <div className="text-lg font-bold text-slate-900">{matches}</div>
                  <div className="text-xs text-slate-500">Matches</div>
                </div>
                
                <div className="text-center">
                  <div className={`w-12 h-12 rounded-xl mx-auto mb-2 flex items-center justify-center ${
                    won ? 'bg-purple-50' : 'bg-slate-50'
                  }`}>
                    <Trophy className={`w-6 h-6 ${won ? 'text-purple-600' : 'text-slate-400'}`} />
                  </div>
                  <div className="text-lg font-bold text-slate-900 capitalize">{difficulty}</div>
                  <div className="text-xs text-slate-500">Level</div>
                </div>
              </div>

              {/* Actions */}
              <div className="space-y-3">
                <Button
                  onClick={onRestart}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-xl font-medium"
                >
                  <RotateCcw className="w-5 h-5 mr-2" />
                  Play Again
                </Button>
                
                <Button
                  onClick={onNewGame}
                  variant="outline"
                  className="w-full py-3 rounded-xl font-medium"
                >
                  <Home className="w-5 h-5 mr-2" />
                  Main Menu
                </Button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}