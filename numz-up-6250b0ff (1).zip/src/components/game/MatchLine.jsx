import React from 'react';
import { motion } from 'framer-motion';

export default function MatchLine({ from, to, gridCols, isHint = false }) {
  const cellSize = 48; // Approximate cell size including gap
  const gridPadding = 16;
  
  const fromX = from.col * cellSize + cellSize / 2 + gridPadding;
  const fromY = from.row * cellSize + cellSize / 2 + gridPadding;
  const toX = to.col * cellSize + cellSize / 2 + gridPadding;
  const toY = to.row * cellSize + cellSize / 2 + gridPadding;
  
  const length = Math.sqrt(Math.pow(toX - fromX, 2) + Math.pow(toY - fromY, 2));
  const angle = Math.atan2(toY - fromY, toX - fromX) * 180 / Math.PI;
  
  return (
    <motion.div
      className="absolute pointer-events-none z-10"
      style={{
        left: fromX,
        top: fromY,
        width: length,
        height: isHint ? 3 : 4,
        transformOrigin: '0 50%',
        transform: `rotate(${angle}deg)`,
      }}
      initial={{ scaleX: 0, opacity: 0 }}
      animate={{ scaleX: 1, opacity: 1 }}
      exit={{ scaleX: 0, opacity: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
    >
      <div 
        className={`w-full h-full rounded-full ${
          isHint 
            ? 'bg-amber-400 animate-pulse' 
            : 'bg-emerald-500 shadow-lg'
        }`}
        style={{
          boxShadow: isHint ? 'none' : '0 0 20px rgba(16, 185, 129, 0.5)'
        }}
      />
    </motion.div>
  );
}