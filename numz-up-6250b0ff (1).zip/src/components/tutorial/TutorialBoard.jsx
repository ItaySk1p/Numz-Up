
import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Lightbulb, ArrowLeft, CheckCircle } from 'lucide-react';

import GameCell from '../game/GameCell';
import TutorialTooltip from './TutorialTooltip';

const tutorialSteps = [
  {
    // Step 1: Horizontal match (Identical) with clear path
    board: [
      [{ v: 7, id: 1 }, { v: null, id: 2 }, { v: 7, id: 3 }]
    ],
    tooltip: { text: "Match identical numbers. The path between them must be clear. Tap the two 7s.", on: [0, 2] },
    match: [0, 2],
    isDone: false,
  },
  {
    // Step 2: Horizontal match (Sum to 10) with clear path
    board: [
      [{ v: 3, id: 4 }, { v: null, id: 5 }, { v: 7, id: 6 }]
    ],
    tooltip: { text: "You can also match numbers that sum to 10, like 3 and 7.", on: [0, 2] },
    match: [0, 2],
    isDone: false,
  },
  {
    // Step 3: Vertical match with clear path
    board: [
      [{ v: 4, id: 7 }],
      [{ v: null, id: 8 }],
      [{ v: 4, id: 9 }]
    ],
    tooltip: { text: "Matching works vertically too, if the path is clear.", on: [0, 2] },
    match: [0, 2],
    isDone: false,
  },
  {
    // Step 4: Diagonal match with clear path
    board: [
      [{ v: 5, id: 10 }, { v: null, id: 11 }],
      [{ v: null, id: 12 }, { v: 5, id: 13 }]
    ],
    tooltip: { text: "And diagonally! Connect the 5s.", on: [0, 3] },
    match: [0, 3],
    isDone: false,
  },
  {
    // Step 5: Hint step with a valid match
    board: [
      [{ v: 2, id: 19 }, { v: null, id: 20 }, { v: 8, id: 21 }]
    ],
    tooltip: { text: "Stuck? The hint button shows a valid match. Try it!", on: ['hint-button'] },
    match: [0, 2], // The match to be revealed by the hint
    isHintStep: true,
    isDone: false,
  },
  {
    // Step 6: Completion
    board: [],
    tooltip: { text: "Great job! You're ready to play.", on: ['center'] },
    isDone: true,
  },
];

export default function TutorialBoard({ onTutorialComplete }) {
  const [stepIndex, setStepIndex] = useState(0);
  const [board, setBoard] = useState([]);
  const [selected, setSelected] = useState(null);
  const [hintUsed, setHintUsed] = useState(false);
  const [showHint, setShowHint] = useState(false);

  const canMatch = useCallback((cell1, cell2, currentBoard) => {
    const { row: r1, col: c1 } = cell1;
    const { row: r2, col: c2 } = cell2;

    const val1 = cell1.value;
    const val2 = cell2.value;

    const isValidMatch = val1 === val2 || val1 + val2 === 10;
    if (!isValidMatch) return false;

    const sameRow = r1 === r2;
    const sameCol = c1 === c2;
    const sameDiag = Math.abs(r1 - r2) === Math.abs(c1 - c2);

    if (!sameRow && !sameCol && !sameDiag) return false;

    const stepR = r1 === r2 ? 0 : (r2 - r1) / Math.abs(r2 - r1);
    const stepC = c1 === c2 ? 0 : (c2 - c1) / Math.abs(c2 - c1);

    let currentR = r1 + stepR;
    let currentC = c1 + stepC;

    while (currentR !== r2 || currentC !== c2) {
      if (currentBoard[currentR] && currentBoard[currentR][currentC] && 
          currentBoard[currentR][currentC].value !== null && 
          !currentBoard[currentR][currentC].cleared) {
        return false;
      }
      currentR += stepR;
      currentC += stepC;
    }

    return true;
  }, []);

  useEffect(() => {
    const currentStep = tutorialSteps[stepIndex];
    const newBoard = currentStep.board.map((row, rowIdx) => 
      row.map((cell, colIdx) => ({
        value: cell.v,
        id: cell.id,
        cleared: cell.v === null,
        glowAnimation: null,
        row: rowIdx,
        col: colIdx
      }))
    );
    setBoard(newBoard);
    setSelected(null);
    setHintUsed(false);
    setShowHint(false);

    if (currentStep.isDone) {
      setTimeout(() => {
        onTutorialComplete();
      }, 2500);
    }
  }, [stepIndex, onTutorialComplete]);
  
  const handleCellClick = (rowIndex, cellIndex) => {
    const currentStep = tutorialSteps[stepIndex];
    if (currentStep.isDone || (currentStep.isHintStep && !hintUsed)) return;

    const clickedCell = board[rowIndex][cellIndex];
    if (clickedCell.cleared) return;

    // Calculate global index for one-dimensional matching array
    const clickedGlobalIndex = board.slice(0, rowIndex).reduce((acc, row) => acc + row.length, 0) + cellIndex;

    if (selected === null) {
      // If no cell is selected, select the clicked one if it's part of the current step's target match
      if (currentStep.match.includes(clickedGlobalIndex)) {
        setSelected(clickedGlobalIndex);
      }
    } else {
      // If a cell is already selected, try to match with the clicked cell
      if (selected !== clickedGlobalIndex && currentStep.match.includes(clickedGlobalIndex)) {
        // Find selected cell's row and col based on its global index
        let selectedRowIndex = 0;
        let selectedColIndex = selected;
        for (let i = 0; i < board.length; i++) {
            if (selectedColIndex < board[i].length) {
                selectedRowIndex = i;
                break;
            }
            selectedColIndex -= board[i].length;
        }

        const selectedCell = board[selectedRowIndex]?.[selectedColIndex];
        
        if (selectedCell && canMatch(selectedCell, clickedCell, board)) {
          // Correct match
          setBoard(prev => prev.map(row => 
            row.map(cell => 
              (cell.id === selectedCell.id || cell.id === clickedCell.id)
                ? { ...cell, cleared: true }
                : cell
            )
          ));
          setTimeout(() => setStepIndex(prev => prev + 1), 1000);
        } else {
            // Incorrect match attempt, deselect
            setSelected(null);
        }
      } else {
        // Clicked the same cell or an invalid second cell for the current step
        setSelected(null);
      }
    }
  };

  const handleHintClick = () => {
    const currentStep = tutorialSteps[stepIndex];
    if (currentStep.isHintStep && !hintUsed) {
      setHintUsed(true);
      setShowHint(true);
      setTimeout(() => setShowHint(false), 1200);
    }
  };

  const currentStep = tutorialSteps[stepIndex];
  const isFinalStep = currentStep.isDone;

  return (
    <div className="flex flex-col h-full bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="flex items-center justify-between p-4 bg-white border-b border-slate-200">
        <Button variant="ghost" size="sm" onClick={onTutorialComplete} className="flex items-center gap-2">
          <ArrowLeft className="w-4 h-4" />
          Back to Menu
        </Button>
        <h1 className="text-xl font-bold text-slate-900">Tutorial</h1>
        <div className="w-24"></div>
      </div>
      
      <div className="flex-1 flex flex-col items-center justify-center p-4 relative">
        <AnimatePresence>
          <TutorialTooltip
            key={stepIndex}
            text={currentStep.tooltip.text}
            target={currentStep.tooltip.on}
            isFinal={isFinalStep}
          />
        </AnimatePresence>
        
        <motion.div
          className="grid gap-2 p-4 bg-white rounded-2xl shadow-xl border border-slate-200"
          style={{ 
            gridTemplateColumns: `repeat(${board[0]?.length || 1}, 1fr)`,
            gridTemplateRows: `repeat(${board.length}, 1fr)`
          }}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          {board.map((row, rowIndex) =>
            row.map((cell, cellIndex) => {
              // Calculate global index for the cell within the flat tutorialSteps.match array
              const globalIndex = board.slice(0, rowIndex).reduce((acc, r) => acc + r.length, 0) + cellIndex;
              return (
                <GameCell
                  key={cell.id}
                  value={cell.value}
                  cleared={cell.cleared}
                  selected={selected === globalIndex}
                  // Only show hint glow if it's the hint step, hint has been used, AND cell is part of the current step's match
                  hinted={showHint && currentStep.match.includes(globalIndex)}
                  onClick={() => handleCellClick(rowIndex, cellIndex)}
                />
              );
            })
          )}
        </motion.div>
        
        {currentStep.isHintStep && (
          <div className="mt-8" id="hint-button">
            <Button
              variant="outline"
              size="sm"
              onClick={handleHintClick}
              disabled={hintUsed}
              className="flex items-center gap-2 bg-amber-50 hover:bg-amber-100 text-amber-700 border-amber-200"
            >
              <Lightbulb className="w-4 h-4" />
              Hint (1)
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
