import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle } from 'lucide-react';

export default function TutorialTooltip({ text, target, isFinal }) {
  const getPosition = () => {
    if (target.includes('center')) {
      return { top: '50%', left: '50%', x: '-50%', y: '-50%', transform: 'translate(-50%, -50%)' };
    }
    if (target.includes('hint-button')) {
      const hintButton = document.getElementById('hint-button');
      if (hintButton) {
        const rect = hintButton.getBoundingClientRect();
        return { 
            top: rect.top - 70, 
            left: rect.left + rect.width / 2,
            x: '-50%',
        };
      }
    }
    return { top: '30%', left: '50%', x: '-50%' };
  };

  if (isFinal) {
    return (
      <motion.div
        className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-20"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <motion.div
          className="flex flex-col items-center gap-4 bg-white p-8 rounded-2xl shadow-2xl"
          initial={{ scale: 0.7, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 300, damping: 20, delay: 0.2 }}
        >
          <CheckCircle className="w-16 h-16 text-emerald-500" />
          <p className="text-xl font-semibold text-slate-800">{text}</p>
        </motion.div>
      </motion.div>
    );
  }

  return (
    <motion.div
      style={getPosition()}
      className="absolute bg-slate-800 text-white p-3 px-4 rounded-lg shadow-lg z-10 max-w-xs text-center"
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 10 }}
      transition={{ type: 'spring', stiffness: 300, damping: 25 }}
    >
      {text}
      <div 
        className="absolute left-1/2 -translate-x-1/2 bottom-[-8px] w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-t-[8px] border-t-slate-800"
      />
    </motion.div>
  );
}