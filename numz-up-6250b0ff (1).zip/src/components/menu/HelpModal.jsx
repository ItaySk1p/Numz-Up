import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  X, 
  Target, 
  Plus, 
  RotateCcw,
  Lightbulb,
  Zap,
  Goal,
  ChevronDown,
  ChevronUp,
  Star
} from 'lucide-react';

export default function HelpModal({ isOpen, onClose }) {
  const [expandedControl, setExpandedControl] = useState(null);

  const toggleControl = (controlName) => {
    setExpandedControl(expandedControl === controlName ? null : controlName);
  };

  const rules = [
    {
      icon: Target,
      title: "Match Numbers",
      desc: "Match identical numbers or numbers that sum to 10",
      example: "3+7=10 or 5+5=10"
    },
    {
      icon: Zap,
      title: "Line of Sight",
      desc: "Numbers must be in same row, column, or diagonal with no blocks between",
      example: "Clear path required"
    },
    {
      icon: Plus,
      title: "Add Rows",
      desc: "Use + button to add 2 new rows at bottom (max 5 times per level)",
      example: "Strategic expansion"
    }
  ];

  const controls = [
    {
      icon: Lightbulb,
      name: "Hint",
      title: "Hint System",
      description: "Shows you a valid match when you're stuck. Hints are earned by making matches:",
      details: [
        "Easy: Earn 1 hint every 5 matches",
        "Medium: Earn 1 hint every 9 matches", 
        "Hard: Earn 1 hint every 15 matches",
        "Highlights two matching numbers for 1 second",
        "Only works when valid matches are available"
      ]
    },
    {
      icon: RotateCcw,
      name: "Undo",
      title: "Undo Last Match",
      description: "Reverses your last match and restores the board state.",
      details: [
        "Restores cleared tiles from your last match",
        "Returns your score to the previous amount",
        "Restores hint count if a hint was earned",
        "Can only undo one move at a time",
        "Disabled if no moves have been made"
      ]
    },
    {
      icon: Plus,
      name: "Add Rows",
      title: "Add More Rows",
      description: "Adds 2 new rows at the bottom when you run out of moves.",
      details: [
        "Only available when no valid matches exist",
        "Adds 2 rows with random numbers",
        "Can be used maximum 5 times per game",
        "Button pulses when it's your only option",
        "New rows use the same digit set as your game"
      ]
    }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            className="bg-white rounded-3xl p-6 max-w-md w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200"
            initial={{ scale: 0.8, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.8, opacity: 0, y: 20 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-slate-900">Game Rules</h2>
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
                className="rounded-full"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>

            {/* Game Rules */}
            <div className="space-y-6">
              {/* Objective */}
              <div>
                <h3 className="text-lg font-semibold text-slate-900 mb-4">Objective</h3>
                <div className="flex gap-4 p-4 bg-slate-50 rounded-2xl">
                  <div className="flex-shrink-0">
                    <div className="w-10 h-10 bg-emerald-100 rounded-xl flex items-center justify-center">
                      <Goal className="w-5 h-5 text-emerald-600" />
                    </div>
                  </div>
                  <div>
                    <div className="font-medium text-slate-900 mb-1">Clear the Board</div>
                    <div className="text-sm text-slate-600">The goal is to clear all numbers from the grid by finding and matching pairs. A level is won when the board is empty.</div>
                  </div>
                </div>
              </div>

              {/* How to Match */}
              <div>
                <h3 className="text-lg font-semibold text-slate-900 mb-4">How to Match</h3>
                <div className="space-y-4">
                  {rules.map((rule, index) => (
                    <motion.div
                      key={index}
                      className="flex gap-4 p-4 bg-slate-50 rounded-2xl"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <div className="flex-shrink-0">
                        <div className="w-10 h-10 bg-emerald-100 rounded-xl flex items-center justify-center">
                          <rule.icon className="w-5 h-5 text-emerald-600" />
                        </div>
                      </div>
                      <div>
                        <div className="font-medium text-slate-900 mb-1">{rule.title}</div>
                        <div className="text-sm text-slate-600 mb-2">{rule.desc}</div>
                        <Badge variant="outline" className="text-xs bg-white">
                          {rule.example}
                        </Badge>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Scoring System */}
              <div>
                <h3 className="text-lg font-semibold text-slate-900 mb-4">Scoring System</h3>
                <div className="space-y-3">
                  <div className="flex gap-4 p-4 bg-slate-50 rounded-2xl">
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 bg-emerald-100 rounded-xl flex items-center justify-center">
                        <Star className="w-5 h-5 text-emerald-600" />
                      </div>
                    </div>
                    <div>
                      <div className="font-medium text-slate-900 mb-1">Base Score</div>
                      <div className="text-sm text-slate-600">Every successful match gives you 2 base points.</div>
                    </div>
                  </div>
                  
                  <div className="flex gap-4 p-4 bg-slate-50 rounded-2xl">
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
                        <Zap className="w-5 h-5 text-blue-600" />
                      </div>
                    </div>
                    <div>
                      <div className="font-medium text-slate-900 mb-1">Distance Bonus</div>
                      <div className="text-sm text-slate-600 mb-2">Get bonus points equal to the number of tiles between your matched numbers.</div>
                      <div className="text-xs text-slate-500">
                        Example: Matching numbers 4 tiles apart = 2 base + 3 bonus = 5 points
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Controls */}
              <div>
                <h3 className="text-lg font-semibold text-slate-900 mb-4">Controls</h3>
                <div className="space-y-2">
                  {controls.map((control, index) => (
                    <div key={control.name} className="border border-slate-200 rounded-xl overflow-hidden">
                      <button
                        onClick={() => toggleControl(control.name)}
                        className="w-full flex items-center justify-between p-4 bg-slate-50 hover:bg-slate-100 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
                            <control.icon className="w-4 h-4 text-slate-600" />
                          </div>
                          <span className="font-medium text-slate-900">{control.title}</span>
                        </div>
                        {expandedControl === control.name ? (
                          <ChevronUp className="w-5 h-5 text-slate-400" />
                        ) : (
                          <ChevronDown className="w-5 h-5 text-slate-400" />
                        )}
                      </button>
                      
                      <AnimatePresence>
                        {expandedControl === control.name && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.2 }}
                            className="overflow-hidden"
                          >
                            <div className="p-4 bg-white border-t border-slate-200">
                              <p className="text-sm text-slate-600 mb-3">{control.description}</p>
                              <ul className="space-y-1">
                                {control.details.map((detail, idx) => (
                                  <li key={idx} className="text-xs text-slate-500 flex items-start gap-2">
                                    <span className="w-1 h-1 bg-slate-400 rounded-full mt-2 flex-shrink-0"></span>
                                    <span>{detail}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  ))}
                </div>
              </div>

              {/* Difficulty Levels */}
              <div>
                <h3 className="text-lg font-semibold text-slate-900 mb-4">Difficulty Levels</h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-center p-3 bg-emerald-50 rounded-xl">
                    <span className="font-medium text-emerald-800">Easy</span>
                    <Badge variant="outline" className="bg-white text-emerald-700">9×9 Grid</Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-amber-50 rounded-xl">
                    <span className="font-medium text-amber-800">Medium</span>
                    <Badge variant="outline" className="bg-white text-amber-700">11×9 Grid</Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-red-50 rounded-xl">
                    <span className="font-medium text-red-800">Hard</span>
                    <Badge variant="outline" className="bg-white text-red-700">13×9 Grid</Badge>
                  </div>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="mt-8 pt-6 border-t border-slate-200">
              <Button
                onClick={onClose}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-xl font-medium"
              >
                Got it!
              </Button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}