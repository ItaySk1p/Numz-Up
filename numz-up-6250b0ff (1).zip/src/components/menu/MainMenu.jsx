
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Play,
  Settings,
  HelpCircle,
  Trophy,
  Zap,
  Target,
  GraduationCap
} from 'lucide-react';

export default function MainMenu({ onStartGame, onShowSettings, onShowHelp, onStartTutorial }) {
  const difficulties = [
    {
      key: 'easy',
      label: 'Easy',
      desc: '9×9 Grid',
      color: 'bg-emerald-500',
      icon: Target
    },
    {
      key: 'medium',
      label: 'Medium',
      desc: '9×13 Grid',
      color: 'bg-amber-500',
      icon: Zap
    },
    {
      key: 'hard',
      label: 'Hard',
      desc: '9×15 Grid',
      color: 'bg-red-500',
      icon: Trophy
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
      <motion.div
        className="max-w-md w-full space-y-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Logo/Thumbnail */}
        <motion.div
          className="text-center space-y-4"
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          <img
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/b9c5cdcea_ChatGPTImageJun19202506_21_35PM.png"
            alt="Numz-Up Game Thumbnail"
            className="w-25 h-25 rounded-3xl shadow-2xl mx-auto object-cover"
            style={{ width: '100px', height: '100px' }}
          />
          <p className="text-slate-300 font-medium italic" style={{ fontSize: '40px' }}>Get your digits together!</p>
        </motion.div>

        {/* Tutorial Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.5 }}
        >
          <Button
            onClick={onStartTutorial}
            className="w-full h-16 bg-emerald-500 hover:bg-emerald-600 border border-emerald-400 rounded-2xl backdrop-blur-sm transition-all duration-200 group text-white text-lg font-semibold"
          >
            <GraduationCap className="w-6 h-6 mr-3" />
            How to Play
          </Button>
        </motion.div>

        {/* Difficulty Selection */}
        <motion.div
          className="space-y-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.5 }}
        >
          <h2 className="text-xl font-semibold text-white text-center mb-2">Or Choose Difficulty</h2>

          {difficulties.map((diff, index) => (
            <motion.div
              key={diff.key}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 + index * 0.1 }}
            >
              <Button
                onClick={() => onStartGame(diff.key)}
                className="w-full h-16 bg-white/10 hover:bg-white/20 border border-white/20 rounded-2xl backdrop-blur-sm transition-all duration-200 group"
                variant="ghost"
              >
                <div className="flex items-center justify-between w-full">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 ${diff.color} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform`}>
                      <diff.icon className="w-6 h-6 text-white" />
                    </div>
                    <div className="text-left">
                      <div className="text-lg font-semibold text-white">{diff.label}</div>
                      <div className="text-sm text-slate-300">{diff.desc}</div>
                    </div>
                  </div>
                  <Play className="w-5 h-5 text-white/60 group-hover:text-white transition-colors" />
                </div>
              </Button>
            </motion.div>
          ))}
        </motion.div>

        {/* Secondary Actions */}
        <motion.div
          className="flex gap-3"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9, duration: 0.5 }}
        >
          <Button
            onClick={onShowSettings}
            variant="ghost"
            className="flex-1 h-12 bg-white/10 hover:bg-white/20 border border-white/20 rounded-xl backdrop-blur-sm text-white"
          >
            <Settings className="w-5 h-5 mr-2" />
            Settings
          </Button>

          <Button
            onClick={onShowHelp}
            variant="ghost"
            className="flex-1 h-12 bg-white/10 hover:bg-white/20 border border-white/20 rounded-xl backdrop-blur-sm text-white"
          >
            <HelpCircle className="w-5 h-5 mr-2" />
            Game Rules
          </Button>
        </motion.div>
      </motion.div>
    </div>
  );
}
