
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { GameSession } from '@/api/entities';
import { ArrowLeft, Settings, Code } from 'lucide-react';

import MainMenu from '../components/menu/MainMenu';
import GameBoard from '../components/game/GameBoard';
import SettingsModal from '../components/menu/SettingsModal';
import HelpModal from '../components/menu/HelpModal';
import TestConsole from '../components/test/TestConsole';
import TutorialBoard from '../components/tutorial/TutorialBoard';

export default function NumberMatchPage() {
  const [gameState, setGameState] = useState('menu'); // 'menu', 'playing', 'tutorial'
  const [difficulty, setDifficulty] = useState('easy');
  const [showSettings, setShowSettings] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  // Removed showTestConsole state as it's now integrated
  const [gameSession, setGameSession] = useState(null);
  const [testMode, setTestMode] = useState(true); // Set to false for production
  const [enabledDigits, setEnabledDigits] = useState([1,2,3,4,5,6,7,8,9]);

  // Test controls for hints and rows
  const [testHints, setTestHints] = useState(1);
  const [testRowsAdded, setTestRowsAdded] = useState(0);

  // Initialize game session
  useEffect(() => {
    if (gameState === 'playing' && !gameSession) {
      createGameSession();
    }
  }, [gameState, gameSession]);

  const createGameSession = async () => {
    try {
      const session = await GameSession.create({
        difficulty,
        board_state: [],
        matches_made: 0,
        hints_available: 1,
        rows_added: 0,
        score: 0,
        enabled_digits: enabledDigits
      });
      setGameSession(session);
    } catch (error) {
      console.error('Failed to create game session:', error);
    }
  };

  const handleStartGame = (selectedDifficulty) => {
    setDifficulty(selectedDifficulty);
    setGameState('playing');
    setGameSession(null); // Reset session to create new one
  };

  const handleStartTutorial = () => {
    setGameState('tutorial');
  };
  
  const handleTutorialComplete = () => {
    setGameState('menu');
  };

  const handleGameComplete = async (won, score) => {
    if (gameSession) {
      try {
        await GameSession.update(gameSession.id, {
          game_completed: won,
          score: score
        });
      } catch (error) {
        console.error('Failed to update game session:', error);
      }
    }
  };

  const handleScoreUpdate = async (score) => {
    if (gameSession) {
      try {
        await GameSession.update(gameSession.id, { score });
      } catch (error) {
        console.error('Failed to update score:', error);
      }
    }
  };

  const handleBackToMenu = () => {
    setGameState('menu');
    setGameSession(null);
  };

  const handleDigitToggle = (digit) => {
    setEnabledDigits(prev => {
      const newDigits = prev.includes(digit)
        ? prev.filter(d => d !== digit)
        : [...prev, digit];

      // Ensure at least one digit is enabled
      return newDigits.length > 0 ? newDigits : prev;
    });
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <AnimatePresence mode="wait">
        {gameState === 'menu' ? (
          <motion.div
            key="menu"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <MainMenu
              onStartGame={handleStartGame}
              onStartTutorial={handleStartTutorial}
              onShowSettings={() => setShowSettings(true)}
              onShowHelp={() => setShowHelp(true)}
            />
          </motion.div>
        ) : gameState === 'playing' ? (
          <motion.div
            key="game"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="h-screen flex flex-col"
          >
            {/* Game Header */}
            <div className="flex items-center justify-between p-4 bg-white border-b border-slate-200">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleBackToMenu}
                className="flex items-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Menu
              </Button>

              <h1 className="text-xl font-bold text-slate-900">Numz-Up</h1>

              <div className="flex items-center gap-1">
                {/* Removed the Code button since TestConsole is now always visible */}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setShowSettings(true)}
                  className="text-slate-500 hover:text-slate-900 rounded-full"
                >
                  <Settings className="w-5 h-5" />
                </Button>
              </div>
            </div>

            {testMode && (
              <TestConsole
                enabledDigits={enabledDigits}
                onDigitToggle={handleDigitToggle}
                hintsAvailable={testHints}
                onHintsChange={setTestHints}
                rowsAdded={testRowsAdded}
                onRowsAddedChange={setTestRowsAdded}
              />
            )}

            {/* Game Board */}
            <div className="flex-1 overflow-auto">
              <GameBoard
                difficulty={difficulty}
                onGameComplete={handleGameComplete}
                onScoreUpdate={handleScoreUpdate}
                enabledDigits={enabledDigits}
                testMode={testMode}
                testHints={testHints}
                testRowsAdded={testRowsAdded}
                onTestHintsChange={setTestHints}
                onTestRowsAddedChange={setTestRowsAdded}
              />
            </div>
          </motion.div>
        ) : ( // gameState === 'tutorial'
          <motion.div
            key="tutorial"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="h-screen flex flex-col"
          >
            <TutorialBoard onTutorialComplete={handleTutorialComplete} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Modals */}
      <SettingsModal
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
      />

      <HelpModal
        isOpen={showHelp}
        onClose={() => setShowHelp(false)}
      />

      {/* Removed TestConsole modal */}
    </div>
  );
}
